# static package initialization 
